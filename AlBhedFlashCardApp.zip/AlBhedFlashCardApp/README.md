I originally created this app in the python script,
However, using the free version of replit.com,
I had my code converted into a web based mobile friendly app.
I have tested it within the replit interface alone.
It absolutely works within the replit interface.
I can not guarantee that the code will work in any other environment.
I am NOT a skilled programmer.
If anyone wants to explore this code you are free to do so.
It is intended as a fun browser based game to learn the Al Bhed Language cipher.
Any and all reference to Final Fantasy X or the Al Bhed Language...
is subject to any and all copywrite issues which I have no control of.
Please respect licensing that has been established.
